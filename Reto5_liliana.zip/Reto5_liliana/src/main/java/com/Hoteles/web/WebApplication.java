package com.Hoteles.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


public class WebApplication {

	public static void main2(String[] args) {
		SpringApplication.run(WebApplication.class, args);
	}

}
